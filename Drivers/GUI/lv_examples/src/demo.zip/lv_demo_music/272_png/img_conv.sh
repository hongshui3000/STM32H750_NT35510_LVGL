php7.2 img_conv_core.php "name=img_lv_demo_music_icon_1&img=icn_heart.png&cf=true_color&format=c_array"
php7.2 img_conv_core.php "name=img_lv_demo_music_icon_2&img=icn_chart.png&cf=true_color&format=c_array"
php7.2 img_conv_core.php "name=img_lv_demo_music_icon_3&img=icn_download.png&cf=true_color&format=c_array"
php7.2 img_conv_core.php "name=img_lv_demo_music_icon_4&img=icn_chat.png&cf=true_color&format=c_array"

php7.2 img_conv_core.php "name=img_lv_demo_music_btn_loop&img=btn_loop.png&cf=true_color_alpha&format=c_array"
php7.2 img_conv_core.php "name=img_lv_demo_music_btn_rnd&img=btn_rnd.png&cf=true_color_alpha&format=c_array"
php7.2 img_conv_core.php "name=img_lv_demo_music_btn_play&img=btn_play.png&cf=true_color_alpha&format=c_array"
php7.2 img_conv_core.php "name=img_lv_demo_music_btn_pause&img=btn_pause.png&cf=true_color_alpha&format=c_array"
php7.2 img_conv_core.php "name=img_lv_demo_music_btn_prev&img=btn_prev.png&cf=true_color_alpha&format=c_array"
php7.2 img_conv_core.php "name=img_lv_demo_music_btn_next&img=btn_next.png&cf=true_color_alpha&format=c_array"
php7.2 img_conv_core.php "name=img_lv_demo_music_slider_knob&img=icn_slider.png&cf=true_color_alpha&format=c_array"

php7.2 img_conv_core.php "name=img_lv_demo_music_btn_list_play&img=btn_list_play.png&cf=true_color_alpha&format=c_array"
php7.2 img_conv_core.php "name=img_lv_demo_music_btn_list_pause&img=btn_list_pause.png&cf=true_color_alpha&format=c_array"
php7.2 img_conv_core.php "name=img_lv_demo_music_list_border&img=list_border.png&cf=true_color_alpha&format=c_array"

php7.2 img_conv_core.php "name=img_lv_demo_music_cover_1&img=cover_1.png&cf=true_color&format=c_array"
php7.2 img_conv_core.php "name=img_lv_demo_music_cover_2&img=cover_2.png&cf=true_color&format=c_array"
php7.2 img_conv_core.php "name=img_lv_demo_music_cover_3&img=cover_3.png&cf=true_color&format=c_array"

php7.2 img_conv_core.php "name=img_lv_demo_music_wave_bottom&img=wave_bottom.png&cf=true_color&format=c_array"
php7.2 img_conv_core.php "name=img_lv_demo_music_wave_top&img=wave_top.png&cf=true_color&format=c_array"
php7.2 img_conv_core.php "name=img_lv_demo_music_corner_left&img=corner_1.png&cf=true_color_alpha&format=c_array"
php7.2 img_conv_core.php "name=img_lv_demo_music_corner_right&img=corner_2.png&cf=true_color_alpha&format=c_array"

php7.2 img_conv_core.php "name=img_lv_demo_music_logo&img=logo.png&cf=true_color&format=c_array"
